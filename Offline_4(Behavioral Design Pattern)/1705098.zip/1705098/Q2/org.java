public interface org{
  public void request(String service);
  public void serve();
  public String get_name();
  public String get_service();
  public void set_mediator(mediator_org mo);
}
