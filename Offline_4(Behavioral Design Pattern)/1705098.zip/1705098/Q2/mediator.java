public interface mediator{
  public void serve(org ob);
  public void request(org ob , String service);
}
